const products=[
 {id:1,name:"LOUD SOUL / ORIGIN",desc:"American Rock Tee — Grey × Black",price:399,code:"ORIGIN"},
 {id:2,name:"LOUD SOUL / AFTER DARK",desc:"American Rock Tee — Black / Grey",price:399,code:"AFTER"},
 {id:3,name:"LOUD SOUL / NOISE",desc:"Premium Street Rock Tee",price:399,code:"NOISE"},
 {id:4,name:"LOUD SOUL / REBEL",desc:"Limited Rock Graphic Tee",price:399,code:"REBEL"}
];
let cart=JSON.parse(localStorage.getItem("loudSoulCart")||"[]");

function renderProducts(){
 document.getElementById("products").innerHTML=products.map(p=>`
 <article class="product">
  <div class="productArt"><div class="miniShirt"><span>${p.code}</span></div></div>
  <div class="productInfo">
   <h3>${p.name}</h3><p>${p.desc}</p><div class="price">฿${p.price.toLocaleString()}</div>
   <div class="size" id="size-${p.id}">${["S","M","L","XL"].map(s=>`<button onclick="chooseSize(${p.id},'${s}',this)">${s}</button>`).join("")}</div>
   <button class="add" onclick="addToCart(${p.id})">ADD TO CART +</button>
  </div>
 </article>`).join("");
}
function chooseSize(id,size,el){document.querySelectorAll(`#size-${id} button`).forEach(b=>b.classList.remove("active"));el.classList.add("active");window[`size${id}`]=size}
function addToCart(id){
 const size=window[`size${id}`]||"M";
 const found=cart.find(x=>x.id===id&&x.size===size);
 if(found)found.qty++; else cart.push({id,size,qty:1});
 save();openCart();
}
function save(){localStorage.setItem("loudSoulCart",JSON.stringify(cart));document.getElementById("cartCount").textContent=cart.reduce((a,x)=>a+x.qty,0)}
function openCart(){renderCart();document.getElementById("cartModal").classList.add("show")}
function closeCart(){document.getElementById("cartModal").classList.remove("show")}
function renderCart(){
 const box=document.getElementById("cartItems");
 if(!cart.length){box.innerHTML="<p style='color:#777'>ยังไม่มีสินค้าในตะกร้า</p>";document.getElementById("total").textContent="฿0";return}
 box.innerHTML=cart.map((x,i)=>{const p=products.find(p=>p.id===x.id);return `<div class="cartRow"><div><b>${p.name}</b><br><small>ไซซ์ ${x.size} × ${x.qty}</small></div><div class="qty"><button onclick="changeQty(${i},-1)">−</button> ${x.qty} <button onclick="changeQty(${i},1)">+</button></div></div>`}).join("");
 const total=cart.reduce((a,x)=>a+products.find(p=>p.id===x.id).price*x.qty,0);
 document.getElementById("total").textContent=`฿${total.toLocaleString()}`;
}
function changeQty(i,n){cart[i].qty+=n;if(cart[i].qty<=0)cart.splice(i,1);save();renderCart()}
function openCheckout(){
 if(!cart.length){alert("กรุณาเลือกสินค้าก่อน");return}
 document.getElementById("orderSummary").value=cart.map(x=>{const p=products.find(p=>p.id===x.id);return `${p.name} / ${x.size} / ${x.qty} ตัว`}).join(", ");
 closeCart();document.getElementById("checkoutModal").classList.add("show")
}
function closeCheckout(){document.getElementById("checkoutModal").classList.remove("show")}
document.getElementById("checkoutForm").addEventListener("submit",e=>{
 e.preventDefault();
 const d=new FormData(e.target);
 const msg=`สวัสดี LOUD SOUL%0Aขอสั่งซื้อ:%0A${encodeURIComponent(d.get("order"))}%0Aชื่อ: ${encodeURIComponent(d.get("name"))}%0Aเบอร์: ${encodeURIComponent(d.get("phone"))}%0Aที่อยู่: ${encodeURIComponent(d.get("address"))}`;
 window.open(`https://line.me/R/oaMessage/@nate1311/?${msg}`,"_blank");
});
document.getElementById("menuBtn").onclick=()=>document.getElementById("navLinks").classList.toggle("open");
renderProducts();save();
